# Translation Management Dashboard

## Overview

A translation management dashboard for tracking and managing video translations across multiple languages and channels. The application enables users to add videos, assign translations to different languages, track translation status, schedule publications, and manage channels. Built as a full-stack TypeScript application with a React frontend and Express backend.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state with automatic caching and refetching
- **UI Components**: shadcn/ui component library built on Radix UI primitives for accessible, composable components
- **Styling**: Tailwind CSS with CSS custom properties for theming (supports light/dark mode)
- **Forms**: React Hook Form with Zod validation via @hookform/resolvers
- **Drag and Drop**: @dnd-kit for sortable language lists
- **Internationalization**: Custom i18n system with JSON translation files (English and Russian)

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ESM modules
- **API Pattern**: RESTful JSON API with endpoints under `/api/*`
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Validation**: Zod schemas generated from Drizzle schemas via drizzle-zod
- **Build System**: Custom esbuild script for production bundling with selective dependency bundling

### Data Layer
- **Database**: PostgreSQL (requires DATABASE_URL environment variable)
- **Schema Location**: `shared/schema.ts` contains all table definitions and relations
- **Key Entities**:
  - Videos: Source videos to be translated
  - Channels: Target channels for publishing translations
  - Translations: Language-specific translation records with status tracking
  - Default Languages: Configurable list of target languages
  - Activity Logs: Audit trail of system events
  - Settings: Application configuration
- **Migrations**: Managed via Drizzle Kit (`drizzle-kit push`)

### Project Structure
```
Dashboard-Builder/
├── client/src/          # React frontend application
│   ├── components/      # UI components (layout, ui, videos)
│   ├── pages/           # Route page components
│   ├── hooks/           # Custom React hooks
│   ├── i18n/            # Translation JSON files
│   └── lib/             # Utilities, providers, query client
├── server/              # Express backend
│   ├── index.ts         # Server entry point with middleware
│   ├── routes.ts        # API route definitions
│   ├── storage.ts       # Database operations layer
│   ├── db.ts            # Database connection pool
│   └── vite.ts          # Vite dev server integration
├── shared/              # Shared code between client/server
│   └── schema.ts        # Drizzle schema definitions
└── script/              # Build scripts
```

### Design Patterns
- **Storage Pattern**: Database operations abstracted through `IStorage` interface in `storage.ts`
- **Provider Pattern**: Theme and language context providers wrap the application
- **Query Pattern**: All data fetching uses React Query with consistent query key conventions
- **Component Composition**: shadcn/ui components are copied into the project for full customization

## External Dependencies

### Database
- **PostgreSQL**: Primary database, connection via `DATABASE_URL` environment variable
- **Drizzle ORM**: Type-safe database queries and schema management
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### Frontend Libraries
- **Radix UI**: Accessible component primitives (dialog, dropdown, tabs, etc.)
- **TanStack React Query**: Server state management
- **date-fns / date-fns-tz**: Date formatting and timezone handling
- **Recharts**: Chart components for statistics page
- **embla-carousel-react**: Carousel functionality
- **vaul**: Drawer component

### Build Tools
- **Vite**: Frontend build and dev server with HMR
- **esbuild**: Backend bundling for production
- **Tailwind CSS**: Utility-first CSS framework
- **PostCSS/Autoprefixer**: CSS processing

### Replit-Specific
- **@replit/vite-plugin-runtime-error-modal**: Error overlay for development
- **@replit/vite-plugin-cartographer**: Development tooling
- **@replit/vite-plugin-dev-banner**: Development environment indicator