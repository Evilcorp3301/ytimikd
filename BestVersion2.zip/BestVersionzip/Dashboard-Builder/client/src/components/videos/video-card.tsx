import { ExternalLink, MoreVertical, Trash2, Edit2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { VideoThumbnail } from "@/components/ui/video-thumbnail";
import { LanguageChip } from "@/components/ui/language-chip";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import type { VideoWithTranslations, TranslationStatus } from "@shared/schema";

interface VideoCardProps {
  video: VideoWithTranslations;
  onLanguageClick?: (videoId: string, language: string) => void;
  onDelete?: (videoId: string) => void;
  onEdit?: (videoId: string) => void;
}

export function VideoCard({ video, onLanguageClick, onDelete, onEdit }: VideoCardProps) {
  const getVideoId = (url: string) => {
    const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\s]+)/);
    return match ? match[1] : null;
  };

  const videoId = getVideoId(video.url);
  const thumbnailUrl = video.thumbnailUrl || (videoId ? `https://img.youtube.com/vi/${videoId}/mqdefault.jpg` : null);

  const translationsByStatus = video.translations.reduce<Record<TranslationStatus, { language: string }[]>>(
    (acc, t) => {
      const status = t.status as TranslationStatus;
      if (!acc[status]) acc[status] = [];
      acc[status].push({ language: t.language });
      return acc;
    },
    { not_started: [], in_progress: [], completed: [] }
  );

  return (
    <Card className="p-4 transition-shadow overflow-hidden" data-testid={`card-video-${video.id}`}>
      <div className="flex gap-3 sm:gap-4">
        <VideoThumbnail thumbnailUrl={thumbnailUrl} title={video.title} />
        <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0 flex-1">
              <h3 className="truncate text-sm font-semibold" data-testid="text-video-title">
                {video.title || "Untitled Video"}
              </h3>
              <a
                href={video.url}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-1 flex items-center gap-1 text-xs text-muted-foreground transition-colors hover:text-foreground"
                data-testid="link-video-url"
              >
                <ExternalLink className="h-3 w-3" />
                <span className="truncate">{video.url}</span>
              </a>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0" data-testid="button-video-menu">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onEdit?.(video.id)} data-testid="menu-item-edit">
                  <Edit2 className="mr-2 h-4 w-4" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => onDelete?.(video.id)}
                  className="text-destructive"
                  data-testid="menu-item-delete"
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {video.translations.map((translation) => (
          <LanguageChip
            key={translation.id}
            language={translation.language}
            status={translation.status as TranslationStatus}
            onClick={() => onLanguageClick?.(video.id, translation.language)}
          />
        ))}
        {video.translations.length === 0 && (
          <span className="text-xs text-muted-foreground">No languages assigned</span>
        )}
      </div>
    </Card>
  );
}
