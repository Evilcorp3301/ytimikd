import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Plus, Video, Search, Filter } from "lucide-react";
import { Header } from "@/components/layout/header";
import { PageContainer } from "@/components/ui/page-container";
import { VideoCard } from "@/components/videos/video-card";
import { TranslationDialog } from "@/components/videos/translation-dialog";
import { EmptyState } from "@/components/ui/empty-state";
import { VideoCardSkeleton } from "@/components/ui/loading-skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useTranslation } from "@/lib/language-provider";
import type { VideoWithTranslations, Channel, Translation } from "@shared/schema";

export default function QueuePage() {
  const { toast } = useToast();
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [deleteVideoId, setDeleteVideoId] = useState<string | null>(null);
  const [selectedTranslation, setSelectedTranslation] = useState<{
    videoId: string;
    language: string;
    translation: Translation | null;
    videoTitle?: string;
  } | null>(null);

  const { data: videos = [], isLoading: videosLoading } = useQuery<VideoWithTranslations[]>({
    queryKey: ["/api/videos"],
  });

  const { data: channels = [] } = useQuery<Channel[]>({
    queryKey: ["/api/channels"],
  });

  const updateTranslationMutation = useMutation({
    mutationFn: async (data: { id: string; updates: Record<string, unknown> }) => {
      const response = await apiRequest("PATCH", `/api/translations/${data.id}`, data.updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/translations"] });
      toast({ title: t("translation.translationUpdated"), description: t("translation.translationUpdatedDescription") });
      setSelectedTranslation(null);
    },
    onError: (error) => {
      toast({
        title: t("common.error"),
        description: error instanceof Error ? error.message : "Failed to update translation",
        variant: "destructive",
      });
    },
  });

  const createTranslationMutation = useMutation({
    mutationFn: async (data: Record<string, unknown>) => {
      const response = await apiRequest("POST", "/api/translations", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/translations"] });
      toast({ title: t("translation.translationUpdated"), description: t("translation.translationUpdatedDescription") });
      setSelectedTranslation(null);
    },
    onError: (error) => {
      toast({
        title: t("common.error"),
        description: error instanceof Error ? error.message : "Failed to create translation",
        variant: "destructive",
      });
    },
  });

  const archiveVideoMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("POST", `/api/videos/${id}/archive`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      toast({ title: t("queue.videoArchived"), description: t("queue.videoArchivedDescription") });
      setDeleteVideoId(null);
    },
    onError: (error) => {
      toast({
        title: t("common.error"),
        description: error instanceof Error ? error.message : "Failed to archive video",
        variant: "destructive",
      });
    },
  });

  const filteredVideos = videos.filter((video) => {
    if (video.isArchived) return false;
    
    const matchesSearch =
      !searchQuery ||
      video.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      video.url.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus =
      statusFilter === "all" ||
      video.translations.some((t) => t.status === statusFilter);

    return matchesSearch && matchesStatus;
  });

  const handleLanguageClick = (videoId: string, language: string) => {
    const video = videos.find((v) => v.id === videoId);
    const translation = video?.translations.find((t) => t.language === language) || null;
    setSelectedTranslation({
      videoId,
      language,
      translation,
      videoTitle: video?.title || undefined,
    });
  };

  const handleSaveTranslation = async (data: Record<string, unknown>) => {
    if (!selectedTranslation) return;
    
    if (selectedTranslation.translation) {
      updateTranslationMutation.mutate({
        id: selectedTranslation.translation.id,
        updates: data,
      });
    } else {
      createTranslationMutation.mutate({
        videoId: selectedTranslation.videoId,
        language: selectedTranslation.language,
        ...data,
      });
    }
  };

  return (
    <div className="flex flex-1 flex-col">
      <Header title={t("queue.title")} />
      <PageContainer>
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-1 items-center gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder={t("queue.searchPlaceholder")}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
                data-testid="input-search"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[140px]" data-testid="select-filter-status">
                <Filter className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("queue.allStatus")}</SelectItem>
                <SelectItem value="not_started">{t("queue.notStarted")}</SelectItem>
                <SelectItem value="in_progress">{t("queue.inProgress")}</SelectItem>
                <SelectItem value="completed">{t("queue.completed")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Link href="/add-video">
            <Button className="gap-2 w-full sm:w-auto" data-testid="button-add-video">
              <Plus className="h-4 w-4" />
              {t("nav.addVideo")}
            </Button>
          </Link>
        </div>

        {videosLoading ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <VideoCardSkeleton key={i} />
            ))}
          </div>
        ) : filteredVideos.length === 0 ? (
          <EmptyState
            icon={Video}
            title={t("queue.noVideos")}
            description={t("queue.noVideosDescription")}
            action={
              <Link href="/add-video">
                <Button className="gap-2" data-testid="button-add-first-video">
                  <Plus className="h-4 w-4" />
                  {t("queue.addFirstVideo")}
                </Button>
              </Link>
            }
          />
        ) : (
          <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {filteredVideos.map((video) => (
              <VideoCard
                key={video.id}
                video={video}
                onLanguageClick={handleLanguageClick}
                onDelete={(id) => setDeleteVideoId(id)}
                onEdit={(id) => window.open(video.url, "_blank")}
              />
            ))}
          </div>
        )}
      </PageContainer>

      <TranslationDialog
        open={!!selectedTranslation}
        onOpenChange={(open) => !open && setSelectedTranslation(null)}
        translation={selectedTranslation?.translation || null}
        language={selectedTranslation?.language || ""}
        videoTitle={selectedTranslation?.videoTitle}
        channels={channels}
        onSave={handleSaveTranslation}
        isLoading={updateTranslationMutation.isPending || createTranslationMutation.isPending}
      />

      <AlertDialog open={!!deleteVideoId} onOpenChange={() => setDeleteVideoId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("queue.archiveVideo")}</AlertDialogTitle>
            <AlertDialogDescription>
              {t("queue.archiveConfirmation")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteVideoId && archiveVideoMutation.mutate(deleteVideoId)}
              data-testid="button-confirm-archive"
            >
              {archiveVideoMutation.isPending ? t("queue.archiving") : t("archive.title")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
