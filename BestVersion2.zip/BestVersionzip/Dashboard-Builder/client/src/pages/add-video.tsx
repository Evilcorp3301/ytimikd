import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowLeft, Plus, X, Video, Loader2 } from "lucide-react";
import { Header } from "@/components/layout/header";
import { PageContainer } from "@/components/ui/page-container";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { VideoThumbnail } from "@/components/ui/video-thumbnail";
import { useTranslation } from "@/lib/language-provider";
import type { DefaultLanguage } from "@shared/schema";

const addVideoSchema = z.object({
  url: z.string().url("Please enter a valid YouTube URL").refine(
    (url) => url.includes("youtube.com") || url.includes("youtu.be"),
    "Please enter a valid YouTube URL"
  ),
  title: z.string().optional(),
  thumbnailUrl: z.string().url().optional().or(z.literal("")),
});

type AddVideoFormValues = z.infer<typeof addVideoSchema>;

export default function AddVideoPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { t } = useTranslation();
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>([]);
  const [previewData, setPreviewData] = useState<{ title?: string; thumbnail?: string } | null>(null);

  const { data: defaultLanguages = [] } = useQuery<DefaultLanguage[]>({
    queryKey: ["/api/languages"],
  });

  const activeLanguages = defaultLanguages.filter((lang) => lang.isActive);

  const form = useForm<AddVideoFormValues>({
    resolver: zodResolver(addVideoSchema),
    defaultValues: {
      url: "",
      title: "",
      thumbnailUrl: "",
    },
  });

  const addVideoMutation = useMutation({
    mutationFn: async (data: AddVideoFormValues & { languages: string[] }) => {
      const response = await apiRequest("POST", "/api/videos", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      toast({
        title: t("addVideo.videoAdded"),
        description: t("addVideo.videoAddedDescription"),
      });
      navigate("/");
    },
    onError: (error) => {
      toast({
        title: t("common.error"),
        description: error instanceof Error ? error.message : "Failed to add video",
        variant: "destructive",
      });
    },
  });

  const handleUrlChange = (url: string) => {
    const videoId = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\s]+)/)?.[1];
    if (videoId) {
      setPreviewData({
        thumbnail: `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`,
      });
    } else {
      setPreviewData(null);
    }
  };

  const toggleLanguage = (code: string) => {
    setSelectedLanguages((prev) =>
      prev.includes(code) ? prev.filter((l) => l !== code) : [...prev, code]
    );
  };

  const selectAllLanguages = () => {
    setSelectedLanguages(activeLanguages.map((l) => l.code));
  };

  const clearLanguages = () => {
    setSelectedLanguages([]);
  };

  const onSubmit = (values: AddVideoFormValues) => {
    if (selectedLanguages.length === 0) {
      toast({
        title: t("addVideo.selectLanguages"),
        description: t("addVideo.selectLanguagesDescription"),
        variant: "destructive",
      });
      return;
    }
    addVideoMutation.mutate({
      ...values,
      languages: selectedLanguages,
    });
  };

  return (
    <div className="flex flex-1 flex-col">
      <Header title={t("addVideo.title")} />
      <PageContainer>
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
            className="gap-2"
            data-testid="button-back"
          >
            <ArrowLeft className="h-4 w-4" />
            {t("addVideo.backToQueue")}
          </Button>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Video className="h-5 w-5" />
                {t("addVideo.videoDetails")}
              </CardTitle>
              <CardDescription>
                {t("addVideo.videoDetailsDescription")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="url"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("addVideo.youtubeUrl")}</FormLabel>
                        <FormControl>
                          <Input
                            placeholder={t("addVideo.youtubeUrlPlaceholder")}
                            {...field}
                            onChange={(e) => {
                              field.onChange(e);
                              handleUrlChange(e.target.value);
                            }}
                            data-testid="input-video-url"
                          />
                        </FormControl>
                        <FormDescription>
                          {t("addVideo.youtubeUrlDescription")}
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {previewData?.thumbnail && (
                    <div className="flex items-center gap-4 rounded-lg border p-4">
                      <VideoThumbnail thumbnailUrl={previewData.thumbnail} size="lg" />
                      <div className="flex-1">
                        <p className="text-sm text-muted-foreground">Video preview</p>
                        {form.watch("title") && (
                          <p className="font-medium">{form.watch("title")}</p>
                        )}
                      </div>
                    </div>
                  )}

                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("addVideo.videoTitle")}</FormLabel>
                        <FormControl>
                          <Input
                            placeholder={t("addVideo.videoTitlePlaceholder")}
                            {...field}
                            data-testid="input-video-title"
                          />
                        </FormControl>
                        <FormDescription>
                          {t("addVideo.videoTitleDescription")}
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full gap-2"
                    disabled={addVideoMutation.isPending}
                    data-testid="button-submit-video"
                  >
                    {addVideoMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        {t("addVideo.adding")}
                      </>
                    ) : (
                      <>
                        <Plus className="h-4 w-4" />
                        {t("addVideo.addToQueue")}
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between gap-4">
                <div>
                  <CardTitle>{t("addVideo.targetLanguages")}</CardTitle>
                  <CardDescription>
                    {t("addVideo.targetLanguagesDescription")}
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={selectAllLanguages}
                    data-testid="button-select-all"
                  >
                    {t("addVideo.selectAll")}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={clearLanguages}
                    data-testid="button-clear-all"
                  >
                    {t("addVideo.clear")}
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {activeLanguages.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">
                    {t("addVideo.noLanguagesConfigured")}
                  </p>
                </div>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {activeLanguages.map((lang) => {
                    const isSelected = selectedLanguages.includes(lang.code);
                    return (
                      <Badge
                        key={lang.code}
                        variant={isSelected ? "default" : "outline"}
                        className="cursor-pointer px-3 py-1.5 text-sm"
                        onClick={() => toggleLanguage(lang.code)}
                        data-testid={`badge-language-${lang.code}`}
                      >
                        {lang.name}
                        {isSelected && <X className="ml-1 h-3 w-3" />}
                      </Badge>
                    );
                  })}
                </div>
              )}
              {selectedLanguages.length > 0 && (
                <p className="mt-4 text-sm text-muted-foreground" data-testid="text-selected-count">
                  {t("addVideo.languagesSelected", { count: selectedLanguages.length })}
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </PageContainer>
    </div>
  );
}
